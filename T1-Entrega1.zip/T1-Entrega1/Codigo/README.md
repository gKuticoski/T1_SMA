# T1_SMA

para executar: python3 main.py

